# Pipeline Engineer ![image](ADD AN IMAGE)

This plugin streamlines the design process of pipeline systems.
Current features include:-
Network Cleanup - Tools to check network topology

Fluid Modelling - Abstract functioning hydraulic models of compressible or incompressible media directly from GIS layers

Bill of Material Generation - Identify features (e.g. tees and bends) and assign fittings within QGIS

-
**Author:** Thomas Raj

**Current mantainer:** Thomas Raj

**email:** *lemungineer@gmail.com*

**Pipeline Engineer license:**

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
